export const environment = {
  production: true,
  apiUrl: 'https://api.monapp.com',
  appName: 'TodoList App'
};